package com.senai.exercicio3.dtos;

public class RespostaCampeonatoDto {
    
}
