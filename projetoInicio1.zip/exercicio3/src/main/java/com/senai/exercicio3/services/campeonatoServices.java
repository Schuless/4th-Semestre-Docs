package com.senai.exercicio3.services;

import com.senai.exercicio3.dtos.*;
import com.senai.exercicio3.models.campeonatoModel;
import java.util.ArrayList;
import org.springframework.stereotype.Service;

@Service
public class campeonatoServices {

    ArrayList<campeonatoModel> listaCampeonatos = new ArrayList<>();

    public boolean cadastrarCampeonato(entradaCampeonatoDto dados) {
        boolean achou = false;

        for (campeonatoModel campeonatoItem : listaCampeonatos) {
            if (campeonatoItem.getNomeCampeonato().equals(dados.getNomeCampeonato())) {
                achou = true;
            }
        }

        return achou;

    }

    public boolean atualizarCampeonato(entradaCampeonatoDto dados) {
        boolean achou = false;

        for (campeonatoModel campeonatoItem : listaCampeonatos) {
            if (campeonatoItem.getCodigoCampeonato().equals(dados.getCodigoCampeonato())) {
                campeonatoItem.setNomeCampeonato(dados.getNomeCampeonato());
                campeonatoItem.setLimiteTimes(dados.getLimiteTimes());
                campeonatoItem.setPremiacaoCampeonato(dados.getPremiacaoCampeonato());
                achou = true;
            }
        }

        return achou;

    }

    public ArrayList<entradaCampeonatoDto> obterListaCampeonatos() {
        ArrayList<entradaCampeonatoDto> listaCampeonatos = new ArrayList<>();
        return listaCampeonatos;
    }
}
