package com.senai.exercicio3.dtos;

public class entradaCampeonatoDto {
    private String nomeCampeonato;
    private double premiacaoCampeonato;
    private int limiteTimes;
    private String codigoCampeonato;

    public entradaCampeonatoDto() {
    }

    public String getNomeCampeonato() {
        return nomeCampeonato;
    }

    public void setNomeCampeonato(String nomeCampeonato) {
        this.nomeCampeonato = nomeCampeonato;
    }

    public double getPremiacaoCampeonato() {
        return premiacaoCampeonato;
    }

    public void setPremiacaoCampeonato(double premiacaoCampeonato) {
        this.premiacaoCampeonato = premiacaoCampeonato;
    }

    public int getLimiteTimes() {
        return limiteTimes;
    }

    public void setLimiteTimes(int limiteTimes) {
        this.limiteTimes = limiteTimes;
    }

    public String getCodigoCampeonato() {
        return codigoCampeonato;
    }

    public void setCodigoCampeonato(String codigoCampeonato) {
        this.codigoCampeonato = codigoCampeonato;
    }
    
    
}
