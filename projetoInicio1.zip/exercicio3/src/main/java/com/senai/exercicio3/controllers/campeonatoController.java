package com.senai.exercicio3.controllers;

import com.senai.exercicio3.dtos.*;
import com.senai.exercicio3.services.campeonatoServices;
import jakarta.validation.Valid;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/campeonato")
public class campeonatoController {

    @Autowired
    campeonatoServices servico;

    @PostMapping
    public ResponseEntity<RespostaCampeonatoDto> cadastrarCampeonato(@RequestBody entradaCampeonatoDto dados) {
        RespostaCampeonatoDto dsa = servico.cadastrarCampeonato(dados);
        return ResponseEntity.ok().body(dsa);
    }

    @PutMapping
    public ResponseEntity<RespostaCampeonatoDto> atualizarCampeonato(@RequestBody entradaCampeonatoDto dados) {
        
        return ResponseEntity.ok().body();
    }

    @GetMapping
    public ResponseEntity<ArrayList<entradaCampeonatoDto>> obterCampeonato(@RequestBody entradaCampeonatoDto dados) {

        return ResponseEntity.ok().body(servico.obterListaCampeonatos());
    }
}
