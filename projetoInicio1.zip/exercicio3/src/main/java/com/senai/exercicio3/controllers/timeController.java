package com.senai.exercicio3.controllers;

import com.senai.exercicio3.dtos.entradaCampeonatoDto;
import com.senai.exercicio3.dtos.RespostaCampeonatoDto;
import com.senai.exercicio3.services.campeonatoServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

public class timeController {

    @Autowired
    campeonatoServices servico;

    @PostMapping
    public ResponseEntity<RespostaCampeonatoDto> cadastrarTime(@RequestBody entradaCampeonatoDto dados) {
        return null;
    }
    
    @PutMapping
    public ResponseEntity<RespostaCampeonatoDto> atualizarTime(@RequestBody entradaCampeonatoDto dados) {
        return null;
    }
}

